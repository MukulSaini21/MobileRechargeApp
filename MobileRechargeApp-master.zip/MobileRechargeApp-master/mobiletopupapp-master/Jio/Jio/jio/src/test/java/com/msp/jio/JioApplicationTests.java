package com.msp.jio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JioApplicationTests {

	@Test
	void contextLoads() {
	}

}
