# mobiletopupapp
Getting Started
Reference Documentation
For further reference, please consider the following sections:

Official Apache Maven documentation
Spring Boot Maven Plugin Reference Guide
Create an OCI image
Spring Data JPA
Spring Web
Spring HATEOAS
Guides
The following guides illustrate how to use some features concretely:

Accessing Data with JPA
Accessing data with MySQL
Building a RESTful Web Service
Serving Web Content with Spring MVC
Building REST services with Spring
Building a Hypermedia-Driven RESTful Web Service


This is a java springboot project making use of restful API services in order to 
1) Generate new User
2) Top Up their balance
3) view the balance
